var express = require('express')

var app = express()

var multipart = require(
        'connect-multiparty'
    );

var MongoClient = require('mongodb').MongoClient;
var multipartMiddleware = multipart();
var url = "mongodb://139.224.19.109:27017/";
 


app.use(express.json()) // for parsing application/json
app.use(express.urlencoded({ extended: true })) // for parsing application/x-www-form-urlencoded

app.post('/login', multipartMiddleware, function (req, res, next) {
    console.log(req.body)
    MongoClient.connect(url, function(err, db) {
        if (err) throw err;
        var dbo = db.db("timelist1");
        var myobj = req.body;
        dbo.collection("timelist1").insertOne(myobj, function(err, res) {
            if (err) throw err;
            console.log("文档插入成功");
            db.close();
        });
    });
        res.header("Access-Control-Allow-Origin", "*");

    res.header("Access-Control-Allow-Headers", "X-Requested-With");

    res.header("Access-Control-Allow-Methods", "PUT,POST,GET,DELETE,OPTIONS");

    res.header("X-Powered-By", ' 3.2.1')

    res.header("Content-Type", "application/json;charset=utf-8");

    res.json(req.body)
})
app.listen(8085, () => {
    console.log('配置完成!')
})